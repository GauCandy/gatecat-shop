import Link from "next/link";

const categories = [
  {
    href: "/laptops",
    label: "Laptop",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="5" width="18" height="12" rx="1.5" />
        <path d="M2 20h20" />
      </svg>
    ),
  },
  {
    href: "/desktops",
    label: "Desktop",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="6" y="3" width="12" height="18" rx="1.5" />
        <circle cx="12" cy="18" r="1" />
      </svg>
    ),
  },
  {
    href: "/gpus",
    label: "Card đồ họa",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="7" width="20" height="10" rx="1.5" />
        <circle cx="8" cy="12" r="2" />
        <circle cx="16" cy="12" r="2" />
      </svg>
    ),
  },
  {
    href: "/cpus",
    label: "CPU",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="6" y="6" width="12" height="12" rx="1.5" />
        <rect x="9" y="9" width="6" height="6" />
        <path d="M12 3v3M12 18v3M3 12h3M18 12h3M3 8h3M18 8h3M3 16h3M18 16h3" />
      </svg>
    ),
  },
  {
    href: "/ram",
    label: "RAM",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="8" width="20" height="8" rx="1" />
        <path d="M6 12h2M10 12h2M14 12h2M18 12h2" />
      </svg>
    ),
  },
  {
    href: "/storage",
    label: "SSD",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="4" y="4" width="16" height="16" rx="2" />
        <path d="M8 9h8M8 13h8M8 17h4" />
      </svg>
    ),
  },
  {
    href: "/monitors",
    label: "Màn hình",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="4" width="20" height="13" rx="1.5" />
        <path d="M8 21h8M12 17v4" />
      </svg>
    ),
  },
  {
    href: "/peripherals",
    label: "Phụ kiện",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 3a4 4 0 0 0-4 4v7a4 4 0 0 0 8 0V7a4 4 0 0 0-4-4Z" />
        <path d="M12 3v6" />
      </svg>
    ),
  },
];

export function CategoryStrip() {
  return (
    <section className="border-b border-[var(--color-border)] bg-white">
      <div className="mx-auto w-full px-4 py-5 sm:px-6 lg:w-2/3 lg:px-0">
        <ul className="grid grid-cols-4 gap-2 sm:grid-cols-8">
          {categories.map((c) => (
            <li key={c.href}>
              <Link
                href={c.href}
                className="group flex flex-col items-center gap-1.5 rounded-xl p-2 transition hover:bg-[var(--color-surface-2)]"
              >
                <span className="grid h-9 w-9 place-items-center rounded-full bg-[var(--color-surface-2)] text-[var(--color-text)] transition group-hover:bg-[var(--color-accent-soft)] group-hover:text-[var(--color-accent)]">
                  <span className="h-4 w-4">{c.icon}</span>
                </span>
                <span className="text-[11px] font-medium text-[var(--color-text-dim)] transition group-hover:text-[var(--color-text)]">
                  {c.label}
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
