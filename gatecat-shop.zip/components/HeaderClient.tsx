"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { SessionUser } from "@/lib/session";
import { UserMenu } from "./UserMenu";

const navItems = [
  { href: "/laptops", label: "Laptop" },
  { href: "/desktops", label: "Desktop" },
  { href: "/components", label: "Linh kiện" },
  { href: "/peripherals", label: "Phụ kiện" },
  { href: "/deals", label: "Khuyến mãi" },
  { href: "/support", label: "Hỗ trợ" },
];

export function HeaderClient({ user }: { user: SessionUser | null }) {
  const [hideSubNav, setHideSubNav] = useState(false);

  useEffect(() => {
    let lastY = window.scrollY;
    const onScroll = () => {
      const y = window.scrollY;
      const delta = y - lastY;
      if (y < 80) {
        setHideSubNav(false);
      } else if (delta > 4) {
        setHideSubNav(true);
      } else if (delta < -4) {
        setHideSubNav(false);
      }
      lastY = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-[var(--color-border)] bg-white/85 backdrop-blur-xl">
        <div className="mx-auto flex h-14 w-full items-center gap-4 px-4 sm:px-6 lg:w-2/3 lg:px-0">
          <Link href="/" className="flex shrink-0 items-center gap-2">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-[var(--color-text)] text-[11px] font-semibold text-white">
              G
            </span>
            <span className="text-[15px] font-semibold tracking-tight">
              Gatecat
            </span>
          </Link>

          <form
            role="search"
            className="relative hidden min-w-0 flex-1 md:block"
            onSubmit={(e) => e.preventDefault()}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--color-text-dim)]"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input
              type="search"
              placeholder="Tìm sản phẩm, danh mục..."
              className="h-9 w-full rounded-full border border-[var(--color-border)] bg-[var(--color-surface-2)] pl-9 pr-4 text-[13px] text-[var(--color-text)] placeholder:text-[var(--color-text-dim)] focus:border-[var(--color-accent)] focus:bg-white focus:outline-none"
            />
          </form>

          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              aria-label="Tìm kiếm"
              className="grid h-9 w-9 place-items-center rounded-full text-[var(--color-text-dim)] transition hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)] md:hidden"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4"
              >
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.3-4.3" />
              </svg>
            </button>

            <button
              type="button"
              aria-label="Giỏ hàng"
              className="relative grid h-9 w-9 place-items-center rounded-full text-[var(--color-text-dim)] transition hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-4 w-4"
              >
                <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
                <path d="M3 6h18" />
                <path d="M16 10a4 4 0 0 1-8 0" />
              </svg>
            </button>

            {user ? (
              <UserMenu user={user} />
            ) : (
              <>
                <Link
                  href="/account"
                  aria-label="Tài khoản"
                  className="grid h-9 w-9 place-items-center rounded-full text-[var(--color-text-dim)] transition hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-4 w-4"
                  >
                    <circle cx="12" cy="8" r="4" />
                    <path d="M4 21a8 8 0 0 1 16 0" />
                  </svg>
                </Link>

                <Link
                  href="/login"
                  className="ml-2 inline-flex items-center rounded-full bg-[var(--color-text)] px-4 py-1.5 text-[13px] font-medium text-white transition hover:bg-black"
                >
                  Đăng nhập
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <nav
        aria-label="Danh mục sản phẩm"
        className={`sticky top-14 z-40 border-b border-[var(--color-border)] bg-white/85 backdrop-blur-xl transition-transform duration-300 ${
          hideSubNav ? "-translate-y-full" : "translate-y-0"
        }`}
      >
        <div className="mx-auto w-full px-4 sm:px-6 lg:w-2/3 lg:px-0">
          <ul className="flex items-center gap-1 overflow-x-auto py-2">
            {navItems.map((item) => (
              <li key={item.href} className="shrink-0">
                <Link
                  href={item.href}
                  className="hologram-frame rounded-full px-3 py-1.5 text-[13px] text-[var(--color-text-dim)] transition hover:bg-[var(--color-surface-2)] hover:text-[var(--color-text)]"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </>
  );
}
