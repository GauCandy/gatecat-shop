import { cookies } from "next/headers";
import { getSessionUser, SESSION_COOKIE } from "@/lib/session";
import { HeaderClient } from "./HeaderClient";

export async function Header() {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = await getSessionUser(token);
  return <HeaderClient user={user} />;
}
