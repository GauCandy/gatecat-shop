# Gatecat Shop — Notes for Claude

## Stack versions

- **Next.js 16** (App Router) — this is NOT Next.js 14/15. APIs changed. Do NOT assume behavior from older versions. When unsure, read the current docs at https://nextjs.org/docs before writing code.
- **React 19**
- **Tailwind CSS 4** (PostCSS plugin via `@tailwindcss/postcss`, theme tokens defined with `@theme` in `app/globals.css`)
- **TypeScript 5**
- **Prisma is NOT used.** Migrations are plain `.sql` files in `db/migrations/` managed by `scripts/migrate.mjs`. DB client is `pg`.

## Known Next.js 16 API changes (vs older versions)

- **`middleware.ts` is renamed to `proxy.ts`**, and the exported function is `proxy` (not `middleware`). See https://nextjs.org/docs/app/api-reference/file-conventions/proxy.
- Route handler `searchParams` in pages is a **Promise** — `await searchParams` in async server components.

If a warning appears like `The "X" file convention is deprecated. Please use "Y" instead.`, follow the linked migration doc rather than guessing.

## Environment

- `.env` (loaded by `dotenv-cli` via npm scripts — see `package.json`):
  - `PORT` — dev/start port
  - `APP_URL` — canonical origin for production (e.g. `https://shop.gatecat.net`). Used as the base for server redirects and the OAuth redirect URI in production. In dev, `requestBase(req)` returns `req.nextUrl.origin` instead so localhost works.
  - `DATABASE_URL` — Postgres connection string
  - `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET` — Google OAuth client

- Host canonicalization (forcing requests onto `APP_URL`) is done at the CDN/reverse-proxy layer, not in the app.

## Database

- Migrations are plain SQL in `db/migrations/NNNN_name.sql`, applied in filename order. Tracked in `_schema_migrations` table. Runner: `scripts/migrate.mjs`. Command: `npm run db:migrate`.
- Tables: `users`, `auth_methods`, `sessions`. Enum: `user_role` (`USER`, `ADMIN`, `SHIPPER`).

## Auth

- Google OAuth only (for now). Flow:
  - `/api/auth/google/start` — generates CSRF state, sets `oauth_state` cookie (10 min), redirects to Google.
  - `/api/auth/google/callback` — verifies state, exchanges code, upserts user + auth_method in a transaction, creates session, sets `session` cookie.
  - `/api/auth/logout` — deletes session row and cookie.
- Session token: random 32 bytes, stored in cookie; DB stores **SHA-256 hash** as the primary key (so a DB leak doesn't expose usable tokens). 30-day expiry.
- Session lookup lives in `lib/session.ts` (`getSessionUser`, `createSession`, `deleteSession`).
- **JWT was considered and rejected** — roles (admin/shipper) require the ability to revoke sessions, which JWT can't do cleanly.

## Conventions

- Redirects that are user-visible should be built with `requestBase(req)` from `lib/env.ts` (returns `APP_URL` in prod, request origin in dev).
- Use the `@/` path alias (maps to project root) for imports.
- Cookies: `httpOnly`, `sameSite: "lax"`, and `secure: cookieSecure` (from `lib/env.ts` — true in prod, false in dev so localhost HTTP works).

## Workflow (instructions for Claude)

After finishing a coherent unit of work, Claude should run these automatically without asking — report only if they fail:

- **After editing app/lib/component code**: run `npm run build`. This is **mandatory**, not optional. Treat any compile error, type error, or build failure as a blocker — fix before declaring the task done. Do not say "done" if build is red.
- **After adding/editing a file in `db/migrations/`**: run `npm run db:migrate`. Never hand-edit a migration that's already been applied — create a new one.
- **After adding a new `remotePatterns` host or new OAuth provider**: restart any running dev server (ask user — don't kill their process).

`npm run build` catches compile/type errors but **NOT runtime errors** like hydration mismatches, bad `useEffect` deps, or SSR-incompatible code. For those: check `app/**/*.tsx` changes that touch state, effects, dates, randomness, or conditional rendering between server/client. If the user reports a hydration error after a CSS/component change in dev, the first thing to try is clearing `.next` and hard-reloading — Turbopack HMR ships stale client bundles fairly often in this project.

Skip the build step for trivial non-code edits (Markdown, comments, SQL-only changes that already got migrated).

## Notes to future Claude sessions

- **`proxy.ts` was intentionally removed.** Host canonicalization lives at the CDN. Do NOT re-add `proxy.ts` / `middleware.ts` for host redirects, even if Next docs suggest it.
- **Dev OAuth works via localhost.** The Google OAuth client has `http://localhost:8443/api/auth/google/callback` registered as a redirect URI (port from `.env` `PORT`). If changing the port, update Google Cloud Console.
- **Tailwind 4 + Next dev HMR occasionally misses new utility classes** (especially in newly created files). If CSS looks unstyled in dev but prod build is fine, the fix is: stop dev, `rm -rf .next`, restart. Don't waste time hunting for config bugs.
- **Do NOT add `Cache-Control: no-store` globally for HTML.** Next.js already sends ETags — browser revalidation returns 304 when unchanged, which is the correct behavior. Overriding to `no-store` kills performance.
- **User prefers industry-standard solutions** over app-level hacks. If you find yourself writing custom middleware/proxy/header logic that a CDN/reverse proxy normally handles, stop and reconsider.
- **Google avatar URLs need `referrerPolicy="no-referrer"`** on the `<img>` tag, otherwise Google returns 403.
